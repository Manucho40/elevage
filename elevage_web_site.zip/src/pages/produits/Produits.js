import React from 'react';
import Banner from '../../components/Banner';
import background from "../../assets/img/image-4.png"

const Produits = () => {
    return (
        <>
            <Banner titre="Nos Produits" background={background}/>
        </>
    );
}

export default Produits;
