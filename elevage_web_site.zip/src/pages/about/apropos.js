import React from 'react';
import Banner from '../../components/Banner';
import background from "../../assets/img/bg-7.jpg"

const Apropos = () => {
    return (
        <>
            <Banner titre="A propos de nous!" background={background}/>
        </>
    );
}

export default Apropos;
